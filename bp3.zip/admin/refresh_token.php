<?php
    // 刷新token接口
    require_once("../functions.php");
    // 调用内置函数，强制刷新
    m_token_refresh(null,true);

